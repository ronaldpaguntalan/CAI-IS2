package com.example.group3_finalproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
